from django.apps import AppConfig


class UserAccountConfig(AppConfig):
    name = 'user_account'
